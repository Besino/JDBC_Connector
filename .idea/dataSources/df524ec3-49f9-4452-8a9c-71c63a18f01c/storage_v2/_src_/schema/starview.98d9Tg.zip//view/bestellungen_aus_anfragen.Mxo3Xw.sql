create view `bestellungen aus anfragen` as
  select
    `starview`.`anfrage`.`idAnfrage`               AS `idAnfrage`,
    `starview`.`anfragentyp`.`Anfragentyp`         AS `Anfragentyp`,
    `starview`.`statusanfrage`.`BezeichnungStatus` AS `BezeichnungStatus`,
    `starview`.`buchung`.`idbuchung`               AS `idbuchung`
  from (((`starview`.`anfrage`
    join `starview`.`anfragentyp` on ((`starview`.`anfrage`.`Typ` = `starview`.`anfragentyp`.`idAnfragentyp`))) join
    `starview`.`statusanfrage`
      on ((`starview`.`anfrage`.`aStatus` = `starview`.`statusanfrage`.`idStatusAnfrage`))) left join
    `starview`.`buchung` on (((`starview`.`buchung`.`Anfrage_idAnfrage` = `starview`.`anfrage`.`idAnfrage`) or
                              (`starview`.`anfrage`.`idAnfrage` = NULL))))
  order by `starview`.`statusanfrage`.`BezeichnungStatus`;

