create view belegungsuebersicht as
  select
    `starview`.`zimmer`.`Zimmernummer`            AS `Zimmernummer`,
    `starview`.`zimmerbelegung`.`Buchung`         AS `Buchung`,
    `starview`.`zimmerbelegung`.`VonDatum`        AS `VonDatum`,
    `starview`.`zimmerbelegung`.`BisDatum`        AS `BisDatum`,
    `starview`.`gaestebelegung`.`person_idperson` AS `GastID`,
    `starview`.`person`.`Vorname`                 AS `VornameGast`,
    `starview`.`person`.`nName`                   AS `NachnameGast`
  from ((((`starview`.`zimmerbelegung`
    join `starview`.`buchung` on ((`starview`.`zimmerbelegung`.`Buchung` = `starview`.`buchung`.`idbuchung`))) join
    `starview`.`zimmer` on ((`starview`.`zimmerbelegung`.`Zimmer` = `starview`.`zimmer`.`idZimmer`))) left join
    `starview`.`gaestebelegung`
      on (((`starview`.`zimmerbelegung`.`Buchung` = `starview`.`gaestebelegung`.`belegung_Buchung`) and
           (`starview`.`zimmerbelegung`.`Zimmer` = `starview`.`gaestebelegung`.`belegung_Zimmer`)))) join
    `starview`.`person` on ((`starview`.`gaestebelegung`.`person_idperson` = `starview`.`person`.`idperson`)))
  order by `starview`.`zimmer`.`Zimmernummer`;

