create view `mitarbeiter hotel` as
  select
    `starview`.`person`.`nName`     AS `nName`,
    `starview`.`person`.`Vorname`   AS `Vorname`,
    `starview`.`person`.`AHVNummer` AS `AHVNummer`
  from `starview`.`person`
  where (`starview`.`person`.`gasteigenschaft_idEigenschaft1` = 1)
  order by `starview`.`person`.`nName`;

